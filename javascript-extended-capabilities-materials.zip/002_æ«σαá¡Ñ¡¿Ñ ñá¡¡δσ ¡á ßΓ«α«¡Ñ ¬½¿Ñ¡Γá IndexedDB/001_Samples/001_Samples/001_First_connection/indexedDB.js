// 1. Открыть БД
// 2. Создать объект хранилища используя новое событие (обновить - изменив версию)
// 3. Начало транзакции и обращение запросов 
// 4. Ожидание завершения операции и прослушивание DOM событий
// 5. Преобразование результатов



// Правило создания: одно приложение - одна база данных. Может быть в БД несколько хранилищ объектов
document.addEventListener('DOMContentLoaded', (e) => {

    // Проверка работы БД в браузере
    window.indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB;
    // Открытие БД 
    let request = indexedDB.open('TaskManager', 1);
    // onupgradeneededсобытие - происходит когда создается новая DB или происходит обновление существующей.
    request.onupgradeneeded = (event) => {
            let DB = event.target.result;
            // Проверка существующего объекта в БД
            if (!DB.objectStoreNames.contains('Tasks')) {
                // Создание объекта хранилища Tasks и присваивание значения id в качестве первичного ключа.
                // autoIncrement - генератор ключей, позволяющий задать уникальное значение для каждого объекта
                var ObjectStore = DB.createObjectStore('Tasks', { keyPath: 'id', autoIncrement: true });
            }
            // options - объект с параметрами, в котором можно указать первоначальный ключ для управления свойствами в БД. 
        }
        // callback функции на обработку ошибок/успеха
    request.onsuccess = (event) => {
        console.log('Success! DB has been opened!');
        // ПОлучение БД
        db = event.target.result;
        // Отображение списка задач
        // showTasks();
    }
    request.onerror = (event) => {
        console.log('Error! There is problem with opening your DB');
    }
});